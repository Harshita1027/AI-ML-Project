import tkinter as tk
from tkinter import ttk, messagebox
import locale
from PIL import Image, ImageTk
from backend import (
    get_models, get_variants, estimate_expenses, recommend_cars, get_car_details
)

# Set Indian locale for ₹ formatting
try:
    locale.setlocale(locale.LC_ALL, 'en_IN.UTF-8')
except:
    locale.setlocale(locale.LC_ALL, '')

# ---------- Root Window ----------
window = tk.Tk()
window.title("Car Expense & Recommendation System")
window.geometry("1000x650")
window.configure(bg="#f3f4f6")

# --- NEW: Font Size Control ---
current_font_size = 11
window.option_add("*Font", f"Segoe {current_font_size}")

style = ttk.Style()
style.theme_use("clam")
style.configure("TButton", padding=6, relief="flat", background="#0078D7", foreground="white")
style.configure("TLabel", background="#f3f4f6")
# --- NEW: Configure Treeview font for scaling ---
style.configure("Treeview", font=("Segoe", current_font_size), rowheight=int(current_font_size * 2.5))
style.configure("Treeview.Heading", font=("Segoe", current_font_size, "bold"))


# ---------- Navigation ----------
def show_frame(frame):
    for f in (home_frame, estimator_frame, recommender_frame):
        f.pack_forget()
    frame.pack(fill="both", expand=True, padx=20, pady=20)

nav_frame = tk.Frame(window, bg="#0078D7")
nav_frame.pack(fill="x")

ttk.Button(nav_frame, text="🏠 Home", command=lambda: show_frame(home_frame)).pack(side="left", padx=10, pady=5)
ttk.Button(nav_frame, text="💰 Expense Estimator", command=lambda: show_frame(estimator_frame)).pack(side="left", padx=10, pady=5)
ttk.Button(nav_frame, text="🚘 Recommender", command=lambda: show_frame(recommender_frame)).pack(side="left", padx=10, pady=5)

# ---------- Home ----------
home_frame = tk.Frame(window, bg="#f3f4f6")
tk.Label(home_frame, text="Welcome to the Car Expense & Recommendation System", font=("Segoe UI", 24, "bold"), bg="#f3f4f6").pack(pady=40)
tk.Label(home_frame, text="Estimate yearly car ownership costs and get car recommendations based on your preferences.", bg="#f3f4f6", font=("Segoe UI", 15, "italic")).pack(pady=10)
tk.Label(home_frame, text="Developed by Harshit, Alyssa, Harshita, Rhythm, Aditya ", bg="#f3f4f6", font=("Segoe UI", 15, "italic")).pack(pady=20)
# --- NEW: Add image to homepage ---
try:
    # 1. Open the image
    img = Image.open("Logo.png")
    # 2. Resize it (e.g., to 400x400)
    img = img.resize((800, 800), Image.LANCZOS)
    # 3. Create a Tkinter-compatible photo
    photo = ImageTk.PhotoImage(img)
    # 4. Create a label to hold the image
    img_label = tk.Label(home_frame, image=photo, bg="#f3f4f6")
    # 5. IMPORTANT: Keep a reference to the image
    img_label.image = photo 
    
    img_label.pack(pady=20)
    
except FileNotFoundError:
    print("WARNING: Homepage image 'Logo' not found.")
except Exception as e:
    print(f"WARNING: Could not load image. Is 'Pillow' installed? Error: {e}")
# --- END of new image code ---

# ---------- Expense Estimator ----------
estimator_frame = tk.Frame(window, bg="#f3f4f6")
tk.Label(estimator_frame, text="Car Expense Estimator", font=("Segoe UI", 16, "bold"), bg="#f3f4f6").pack(pady=10)

est_form = tk.Frame(estimator_frame, bg="#f3f4f6")
est_form.pack(pady=10)

# Dropdowns
ttk.Label(est_form, text="Make:").grid(row=0, column=0, padx=10, pady=5, sticky="e")
make_cb = ttk.Combobox(est_form, state="readonly", width=20, values=[])
make_cb.grid(row=0, column=1, padx=10, pady=5)

ttk.Label(est_form, text="Model:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
model_cb = ttk.Combobox(est_form, state="readonly", width=20)
model_cb.grid(row=1, column=1, padx=10, pady=5)

ttk.Label(est_form, text="Variant:").grid(row=2, column=0, padx=10, pady=5, sticky="e")
variant_cb = ttk.Combobox(est_form, state="readonly", width=20)
variant_cb.grid(row=2, column=1, padx=10, pady=5)

ttk.Label(est_form, text="Years of Ownership:").grid(row=3, column=0, padx=10, pady=5, sticky="e")
years_entry = ttk.Entry(est_form, width=10)
years_entry.grid(row=3, column=1, padx=10, pady=5)

ttk.Label(est_form, text="Daily Kilometers:").grid(row=4, column=0, padx=10, pady=5, sticky="e")
daily_km_entry = ttk.Entry(est_form, width=10)
daily_km_entry.grid(row=4, column=1, padx=10, pady=5)

# --- MODIFIED: Update model and variant on change ---
def update_models(event=None):
    all_models_map = get_models() # Gets the full dictionary
    # Safely get the list of models for the selected make
    models = all_models_map.get(make_cb.get(), []) 
    model_cb["values"] = sorted(models)
    model_cb.set("")
    variant_cb["values"] = []
    variant_cb.set("")

def update_variants(event=None):
    variants = get_variants(make_cb.get(), model_cb.get())
    variant_cb["values"] = variants
    variant_cb.set("")

make_cb["values"] = ["Select Make"] + sorted(get_models().keys())
make_cb.bind("<<ComboboxSelected>>", update_models)
model_cb.bind("<<ComboboxSelected>>", update_variants)

# Result label
result_text = tk.Text(estimator_frame, width=100, height=15, wrap="word", bg="#ffffff", fg="#000000", relief="flat", font=("Segoe", current_font_size))
result_text.pack(pady=15)

# --- MODIFIED: calculate_expense function ---
def calculate_expense():
    try:
        make, model, variant = make_cb.get(), model_cb.get(), variant_cb.get()
        
        if not all([make, model, variant, years_entry.get(), daily_km_entry.get()]):
            messagebox.showerror("Error", "Please fill in all fields.")
            return
        
        years = float(years_entry.get())
        daily_km = float(daily_km_entry.get())
        
        result = estimate_expenses(make, model, variant, daily_km)
        details = get_car_details(make, model, variant)

        result_text.delete("1.0", "end")
        
        if result and details:
            # Get costs from the backend result
            daily_running_cost = result['daily_running_cost']
            maint_per_year = result['maintenance_per_year']
            ins_per_year = result['insurance_per_year']
            price_rs = details.get('Price_Rs') or 0 # Get car price
            
            # Calculate annual and multi-year costs
            annual_fuel_cost = daily_running_cost * 365
            total_annual_ownership_cost = annual_fuel_cost + maint_per_year + ins_per_year
            
            # --- NEW: Total cost over N years ---
            total_cost_over_years = (total_annual_ownership_cost * years) + price_rs
            
            # Get display details
            fuel_type = details.get('Fuel_Type', 'N/A')
            mileage = details.get('Mileage', 'N/A')

            # Display all results clearly
            result_text.insert("end", f"Make: {result['make']}\nModel: {result['model']}\nVariant: {result['variant']}\n")
            result_text.insert("end", f"Price (Ex-Showroom): {locale.currency(price_rs, grouping=True)}\n\n")
            
            result_text.insert("end", f"Fuel Type: {fuel_type}\nMileage: {mileage} km/l\n")
            result_text.insert("end", f"Daily Running Cost (@ {daily_km}km/day): {locale.currency(daily_running_cost, grouping=True)}\n")
            result_text.insert("end", f"Annual Fuel Cost (Est.): {locale.currency(annual_fuel_cost, grouping=True)}\n")
            result_text.insert("end", f"Annual Maintenance (Est.): {locale.currency(maint_per_year, grouping=True)}\n")
            result_text.insert("end", f"Annual Insurance (Est.): {locale.currency(ins_per_year, grouping=True)}\n\n")

            # Configure 'bold' tag
            result_text.tag_configure("bold", font=("Segoe", current_font_size, "bold"))
            result_text.insert("end", "Total Annual Ownership Cost (Est.): ", "bold")
            result_text.insert("end", f"{locale.currency(total_annual_ownership_cost, grouping=True)}\n", "bold")
            
            # --- NEW: Display total cost over N years ---
            result_text.insert("end", f"\nTotal {years}-Year Ownership Cost (Est. + Price): ", "bold")
            result_text.insert("end", f"{locale.currency(total_cost_over_years, grouping=True)}\n", "bold")
            
            result_text.insert("end", f"\nCost/km: {locale.currency(result['cost_per_km'], grouping=True)}\n")
        else:
            result_text.insert("end", f"Could not find expense details for {make} {model} {variant}.")
            
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers for Years and Daily Kilometers.")
    except Exception as e:
        messagebox.showerror("Error", f"Error in calculation: {e}")

ttk.Button(estimator_frame, text="Estimate Expenses", command=calculate_expense).pack(pady=5)


# ---------- Car Recommender ----------
recommender_frame = tk.Frame(window, bg="#f3f4f6")
tk.Label(recommender_frame, text="Car Recommender", font=("Segoe UI", 16, "bold"), bg="#f3f4f6").pack(pady=10)

rec_form = tk.Frame(recommender_frame, bg="#f3f4f6")
rec_form.pack(pady=10)

ttk.Label(rec_form, text="Budget (₹ in lakhs):").grid(row=0, column=0, padx=10, pady=5, sticky="e")
budget_entry = ttk.Entry(rec_form, width=15)
budget_entry.grid(row=0, column=1, padx=10, pady=5)

ttk.Label(rec_form, text="Fuel Type:").grid(row=1, column=0, padx=10, pady=5, sticky="e")
fuel_cb = ttk.Combobox(rec_form, state="readonly", width=15, values=["PETROL", "DIESEL", "CNG", "EV"])
fuel_cb.grid(row=1, column=1, padx=10, pady=5)

ttk.Label(rec_form, text="Seats:").grid(row=2, column=0, padx=10, pady=5, sticky="e")
seat_entry = ttk.Entry(rec_form, width=15)
seat_entry.grid(row=2, column=1, padx=10, pady=5)

ttk.Label(rec_form, text="Daily KM:").grid(row=3, column=0, padx=10, pady=5, sticky="e")
daily_entry = ttk.Entry(rec_form, width=15)
daily_entry.grid(row=3, column=1, padx=10, pady=5)

columns = ("Make", "Model", "Variant", "Fuel Type", "Efficiency", "Total Cost (₹)")
tree = ttk.Treeview(recommender_frame, columns=columns, show="headings", height=10)
for col in columns:
    tree.heading(col, text=col)
    tree.column(col, width=150)
tree.pack(pady=10, fill="x")

# --- MODIFIED: recommend function ---
def recommend():
    try:
        if not all([budget_entry.get(), fuel_cb.get(), seat_entry.get(), daily_entry.get()]):
             messagebox.showerror("Error", "Please fill in all fields.")
             return
             
        budget = float(budget_entry.get())
        fuel_type = fuel_cb.get()
        seats = int(seat_entry.get())
        daily_km = float(daily_entry.get())
        
        results = recommend_cars(
            budget_lakhs=budget, 
            fuel_pref=fuel_type, 
            daily_km=daily_km, 
            seats_pref=seats,
            want_isofix=None
        )

        for row in tree.get_children():
            tree.delete(row)
            
        # ... (inside your 'recommend' function, after 'tree.delete') ...
        
        if not results:
            messagebox.showinfo("No Results", "No cars found matching your criteria.")
            return

        # --- MODIFIED: Logic to show EV Range in 'Efficiency' column ---
        for car in results:
            fuel_type = car.get('Fuel_Type', 'N/A')
            
            # Check fuel type to decide what to display
            if fuel_type == 'EV':
                efficiency_val = f"{car.get('Electric_Range_km', 'N/A')} km"
            else:
                efficiency_val = f"{car.get('Mileage', 'N/A')} km/l"

            values_tuple = (
                car.get('Make', 'N/A'),
                car.get('Model', 'N/A'),
                car.get('Variant', 'N/A'),
                fuel_type,
                efficiency_val,  # <-- Use the new dynamic value
                locale.currency(car.get('Price_Rs'), grouping=True) 
            )
            tree.insert("", "end", values=values_tuple)
            
    except ValueError:
        messagebox.showerror("Error", "Please enter valid numbers for budget, seats, and daily KM.")
    # ... (rest of the function) ...
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {e}")

ttk.Button(recommender_frame, text="Find Cars", command=recommend).pack(pady=5)


# --- NEW: Font sizing functions ---
def change_font_size(delta):
    global current_font_size
    new_size = current_font_size + delta
    if 8 <= new_size <= 20: # Set reasonable limits
        current_font_size = new_size
        font_name = "Segoe"
        
        # 1. Update default Tk font (for new widgets)
        window.option_add("*Font", f"{font_name} {current_font_size}")
        
        # 2. Update all ttk styles
        style.configure(".", font=(font_name, current_font_size))
        
        # 3. Update specific widgets
        result_text.config(font=(font_name, current_font_size))
        result_text.tag_configure("bold", font=(font_name, current_font_size, "bold"))
        
        style.configure("Treeview", font=(font_name, current_font_size), rowheight=int(current_font_size * 2.5))
        style.configure("Treeview.Heading", font=(font_name, current_font_size, "bold"))
        
        # Note: Labels with hardcoded fonts (e.g., "Segoe UI 18 bold") won't scale
        # To fix that, they would need to be stored in variables and re-configured here.

def increase_font(event=None):
    change_font_size(1)

def decrease_font(event=None):
    change_font_size(-1)

# --- NEW: Bind key shortcuts ---
window.bind("<Control-plus>", increase_font)
window.bind("<Control-equal>", increase_font) # 'plus' is often on 'equal' key
window.bind("<Control-minus>", decrease_font)


# ---------- Start ----------
show_frame(home_frame)
window.mainloop()