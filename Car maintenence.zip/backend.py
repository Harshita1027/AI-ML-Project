# backend.py
# ==========================================================
# Car Expense Estimation & Recommendation System (Backend)
# - Loads, cleans, and derives features from cars_ds_final.csv
# - Clusters with KMeans
# - Trains RandomForest (includes ISOFIX as a feature)
# - Saves cleaned dataset and model artifacts for frontend
# ==========================================================

import logging
import re
import joblib
import numpy as np
import pandas as pd
from typing import Optional, Tuple

from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.exceptions import NotFittedError
# --- Add this to the top of backend.py ---

# ---------------------------
# Logging setup
# ---------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

# ---------------------------
# Constants & configuration
# ---------------------------
FUEL_PRICE_PER_UNIT = {
    # Indicative INR values (per litre/kg); update per city if needed
    "PETROL": 95.0,
    "DIESEL": 88.0,
    "CNG": 76.0
}
EV_COST_PER_KM_DEFAULT = 2.0  # INR/km
SUPPORTED_FUELS = {"PETROL", "DIESEL", "CNG", "EV"}

CLEANED_DATASET_PATH = "cars_dataset_cleaned.csv"
FRONTEND_DATASET_PATH = "cars_dataset_for_frontend.csv"
SCALER_PATH = "scaler.pkl"
MODEL_PATH = "car_recommender_model.pkl"
FUEL_ENCODER_PATH = "fuel_encoder.pkl"

# ---------------------------
# Utility & parsing helpers
# ---------------------------
def extract_numbers(s) -> list:
    """Return list of float numbers found in a string."""
    if pd.isna(s):
        return []
    s = str(s).replace(",", "")
    return [float(m) for m in re.findall(r"\d+\.\d+|\d+", s)]


def normalize_fuel_type(val: str) -> str:
    """Normalize fuel type to one of SUPPORTED_FUELS (uppercase)."""
    if pd.isna(val) or val is None:
        return ""
    s = str(val).strip().upper()
    # Map common EV variants
    ev_aliases = {"EV", "E-V", "ELECTRIC", "ELECTRIC VEHICLE", "BEV"}
    if s in ev_aliases:
        return "EV"
    return s


def parse_price_to_rupees(val) -> float:
    """
    Parse price strings like 'Rs. 2,92,667', '6.3 Lakh', or '6.30' (lakhs).
    Returns price in rupees (float) or np.nan.
    """
    if pd.isna(val):
        return np.nan
    nums = extract_numbers(val)
    if not nums:
        return np.nan
    v = np.mean(nums)
    # Heuristic: >= 1000 means direct rupees; otherwise assume lakhs.
    return float(v if v >= 1000 else v * 100000.0)


def parse_mileage(val, fuel_type: Optional[str] = None) -> float:
    """
    Parse mileage strings like '23.6 km/litre', '36 km/kg', '20.3', '22.5/24.5'.
    For EVs, return np.nan (use EV cost per km or range).
    """
    ft = normalize_fuel_type(fuel_type)
    if ft == "EV":
        return np.nan
    nums = extract_numbers(val)
    if not nums:
        defaults = {"PETROL": 17.5, "DIESEL": 22.0, "CNG": 25.0}
        return defaults.get(ft, np.nan)
    m = float(np.mean(nums))
    return m if 0 < m < 500 else np.nan


def parse_int_safe(x) -> Optional[int]:
    """Parse first integer found; return np.nan if none."""
    if pd.isna(x):
        return np.nan
    nums = extract_numbers(x)
    return int(nums[0]) if nums else np.nan


def parse_isofix(val) -> int:
    """Map ISOFIX-like values to 1/0."""
    if pd.isna(val):
        return 0
    s = str(val).strip().lower()
    truthy = {"yes", "y", "true", "1", "present", "available", "supported", "included", "isofix", "with isofix"}
    return int(s in truthy)


def compute_ev_cost_per_km(row) -> float:
    """
    Compute EV cost per km. If Battery (kWh) and Electric_Range (km) exist,
    estimate using INR per kWh ~ 8 (domestic), else default.
    cost_per_km ~ (battery_kWh * tariff) / range_km
    """
    battery = row.get("Battery_kWh", np.nan)
    erange = row.get("Electric_Range_km", np.nan)
    tariff = 8.0  # INR/kWh (approx; configurable)

    if not pd.isna(battery) and not pd.isna(erange) and erange > 0:
        return round((battery * tariff) / erange, 2)
    return EV_COST_PER_KM_DEFAULT


def compute_cost_per_km(row) -> float:
    """
    Cost per km:
    - PETROL/DIESEL: price per litre / mileage (km/l)
    - CNG: price per kg / mileage (km/kg)
    - EV: compute_ev_cost_per_km
    """
    ft = normalize_fuel_type(row.get("Fuel_Type", ""))
    mileage = row.get("Mileage", np.nan)

    if ft == "EV":
        return compute_ev_cost_per_km(row)

    unit_price = FUEL_PRICE_PER_UNIT.get(ft, np.nan)
    if pd.isna(unit_price) or pd.isna(mileage) or mileage <= 0:
        return np.nan
    return round(unit_price / mileage, 2)


# ---------------------------
# Data loading & cleaning
# ---------------------------
def load_and_clean(csv_path: str = "cars_ds_final.csv", save_clean: bool = True) -> pd.DataFrame:
    """
    Load dataset, normalize columns, parse features, and compute derived metrics.
    Returns a cleaned DataFrame ready for modeling.
    """
    logging.info(f"Loading dataset from {csv_path} ...")
    df = pd.read_csv(csv_path, dtype=str)
    df.columns = df.columns.str.strip()

    # Expected mapping (best-effort)
    rename_map = {
        "Make": "Make",
        "Model": "Model",
        "Variant": "Variant",
        "Ex-Showroom_Price": "Price",
        "Fuel_Type": "Fuel_Type",
        "City_Mileage": "Mileage",
        "ARAI_Certified_Mileage_for_CNG": "Mileage_CNG",
        "Electric_Range": "Electric_Range",
        "Battery": "Battery",
        "Seating_Capacity": "Seats",
        "Boot_Space": "Boot_Space",
        "ISOFIX_(Child-Seat_Mount)": "ISOFIX",
        # Flexible catch for varied dataset labels:
        "ARAI_Mileage": "Mileage_ARAI",
        "ARAI_Certified_Mileage": "Mileage_ARAI",
    }
    existing_renames = {k: v for k, v in rename_map.items() if k in df.columns}
    df = df.rename(columns=existing_renames)

    # Normalize fuel type early (uppercase + EV aliases)
    df["Fuel_Type"] = df.get("Fuel_Type", "").astype(str).map(normalize_fuel_type)

    # Parse price
    df["Price_Rs"] = df.get("Price", "").apply(parse_price_to_rupees)

    # Seating
    df["Seats"] = df.get("Seats", np.nan).apply(parse_int_safe)

    # ISOFIX flag
    df["ISOFIX_flag"] = df.get("ISOFIX", 0).apply(parse_isofix)

    # Electric range and battery numeric
    df["Electric_Range_km"] = df.get("Electric_Range", np.nan).apply(
        lambda x: np.mean(extract_numbers(x)) if not pd.isna(x) and extract_numbers(x) else np.nan
    )
    df["Battery_kWh"] = df.get("Battery", np.nan).apply(
        lambda x: np.mean(extract_numbers(x)) if not pd.isna(x) and extract_numbers(x) else np.nan
    )

    # Merge mileage fields with strict CNG preference
    def merged_mileage(row):
        ft = row.get("Fuel_Type", "")
        # Prefer CNG-specific mileage when fuel is CNG
        if ft == "CNG" and "Mileage_CNG" in df.columns:
            val = row.get("Mileage_CNG", np.nan)
            if not pd.isna(val):
                return parse_mileage(val, ft)
        # Primary Mileage column
        val = row.get("Mileage", np.nan)
        if not pd.isna(val):
            return parse_mileage(val, ft)
        # Try any ARAI mileage column if available
        for col in df.columns:
            if "mileage" in col.lower() and col not in ["Mileage", "Mileage_CNG"]:
                val2 = row.get(col, np.nan)
                if not pd.isna(val2):
                    return parse_mileage(val2, ft)
        # Defaults
        return parse_mileage(np.nan, ft)

    df["Mileage"] = df.apply(merged_mileage, axis=1)

    # Compute cost per km
    df["Cost_per_km"] = df.apply(compute_cost_per_km, axis=1)
    # Estimate insurance & maintenance based on price, engine CC, and make
    def estimate_insurance_maint(row):
        make = str(row.get("Make", "")).strip().title()
        price = row.get("Price_Rs", 0)
        displacement = parse_int_safe(row.get("Displacement", np.nan))

        # Normalize engine CC
        cc = displacement if displacement and displacement > 100 else 1000

        # Base multipliers
        make_factors = {
            "Maruti Suzuki": 0.7, "Tata": 0.8, "Hyundai": 0.9,
            "Honda": 1.0, "Toyota": 1.1, "Ford": 1.2, "Volkswagen": 1.3,
            "Kia": 0.9, "Bmw": 1.8, "Mercedes": 2.0, "Audi": 1.5,
            "Jaguar": 2.0, "Lamborghini": 3.0, "Ferrari": 3.2, "Mg": 1.2,
            "Mahindra": 1.0, "Renault": 1.0, "Nissan": 1.0, "Skoda": 1.3
        }
        make_factor = make_factors.get(make, 1.0)

        # Insurance: roughly 3% of price per year, scaled
        insurance_yr = price * 0.03 * make_factor
        # Maintenance: base on engine size and make
        maint_yr = 5000 + (cc * 1.2 * make_factor)

        return pd.Series({"Insurance_per_year": insurance_yr, "Maintenance_per_year": maint_yr})

# Apply to the 'df' DataFrame, not 'df_clean'
    df = df.join(df.apply(estimate_insurance_maint, axis=1))
    df["Total_Annual_Cost"] = (
        df["Insurance_per_year"] + df["Maintenance_per_year"]
    )



    # Validation: drop unusable rows
    req_cols = ["Price_Rs", "Fuel_Type"]
    df_clean = df.dropna(subset=req_cols).copy()

    if df_clean.empty:
        raise RuntimeError("After cleaning, no valid rows left. Check CSV input and column names.")

    # Optional: remove fuel types not in supported set
    df_clean = df_clean[df_clean["Fuel_Type"].isin(SUPPORTED_FUELS)]

    # If mileage missing for non-EV, fill with fuel defaults to keep rows usable
    def fill_mileage(row):
        if row["Fuel_Type"] != "EV" and (pd.isna(row["Mileage"]) or row["Mileage"] <= 0):
            defaults = {"PETROL": 17.5, "DIESEL": 22.0, "CNG": 25.0}
            return defaults.get(row["Fuel_Type"], np.nan)
        return row["Mileage"]

    df_clean["Mileage"] = df_clean.apply(fill_mileage, axis=1)
    df_clean["Cost_per_km"] = df_clean.apply(compute_cost_per_km, axis=1)

    if save_clean:
        df_clean.to_csv(CLEANED_DATASET_PATH, index=False)
        logging.info(f"Saved cleaned dataset to {CLEANED_DATASET_PATH}")

    return df_clean


# ---------------------------
# K-Means clustering
# ---------------------------
def apply_kmeans(df: pd.DataFrame, n_clusters: int = 3) -> Tuple[pd.DataFrame, KMeans, StandardScaler]:
    """
    Apply KMeans clustering on key numeric features and save scaler.
    """
    features = ["Price_Rs", "Mileage", "Cost_per_km"]
    if not all(col in df.columns for col in features):
        raise ValueError(f"KMeans missing required features: {features}")

    # Fill missing with medians for stability
    X_input = df[features].copy()
    for col in features:
        med = X_input[col].median()
        X_input[col] = X_input[col].fillna(med)

    scaler = StandardScaler()
    X = scaler.fit_transform(X_input)

    kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
    df = df.copy()
    df["Cluster"] = kmeans.fit_predict(X)

    joblib.dump(scaler, SCALER_PATH)
    logging.info("KMeans applied and scaler saved.")
    return df, kmeans, scaler


# ---------------------------
# Random Forest training
# ---------------------------
def train_random_forest(df: pd.DataFrame, use_gridsearch: bool = False) -> Tuple[RandomForestClassifier, LabelEncoder]:
    """
    Train RandomForest to rank/score models using tabular features.
    Includes class_weight to reduce bias toward frequent models.
    """
    # Encode fuel type
    le_fuel = LabelEncoder()
    df = df.copy()
    df["Fuel_Encoded"] = le_fuel.fit_transform(df["Fuel_Type"].astype(str))

    feature_cols = ["Price_Rs", "Fuel_Encoded", "Mileage", "Cost_per_km", "Seats", "ISOFIX_flag"]
    for col in feature_cols:
        if col not in df.columns:
            raise ValueError(f"Missing feature column: {col}")

    X = df[feature_cols].copy()
    # fill NaNs with medians
    X = X.fillna(X.median(numeric_only=True))
    y = df["Model"].astype(str)

    # Filter out extremely rare models (<2 samples)
    counts = y.value_counts()
    keep_labels = counts[counts >= 2].index
    keep_mask = y.isin(keep_labels)
    X, y = X[keep_mask], y[keep_mask]

    if len(y.unique()) < 2:
        raise ValueError("Not enough model classes after filtering rare samples for training.")

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    if use_gridsearch:
        params = {
            "n_estimators": [100, 200],
            "max_depth": [None, 20],
            "min_samples_leaf": [1, 2],
        }
        base = RandomForestClassifier(random_state=42, class_weight="balanced")
        grid = GridSearchCV(base, params, cv=3, n_jobs=-1)
        grid.fit(X_train, y_train)
        rf = grid.best_estimator_
        logging.info(f"GridSearch best params: {grid.best_params_}")
    else:
        rf = RandomForestClassifier(
            n_estimators=150,
            random_state=42,
            class_weight="balanced",
            max_depth=None,
        )
        rf.fit(X_train, y_train)

    acc = rf.score(X_test, y_test)
    cv_scores = cross_val_score(rf, X, y, cv=3)
    logging.info(f"RandomForest accuracy (test): {acc*100:.2f}% | CV mean: {cv_scores.mean()*100:.2f}%")

    joblib.dump(rf, MODEL_PATH)
    joblib.dump(le_fuel, FUEL_ENCODER_PATH)
    logging.info(f"Saved model to {MODEL_PATH} and fuel encoder to {FUEL_ENCODER_PATH}")

    return rf, le_fuel


# ---------------------------
# Recommendation (backend helper)
# ---------------------------
def recommend_top_k(
    rf: RandomForestClassifier,
    le_fuel: LabelEncoder,
    df: pd.DataFrame,
    budget_lakhs: float,
    fuel_pref: str,
    daily_km: float,
    seats_pref: Optional[int] = None,
    want_isofix: Optional[bool] = None,
    top_k: int = 5
) -> pd.DataFrame:
    """
    Return top_k recommendations given user preferences.
    Scoring blend:
      - Probabilistic relevance from RF via class probabilities (synthetic user vector)
      - Budget closeness
      - Efficiency (lower cost_per_km)
      - Seat and ISOFIX preference filters (soft if empty sets)
    Note: EV rows display Electric_Range_km in frontend; backend computes cpk via EV logic.
    """
    if budget_lakhs <= 0:
        raise ValueError("Budget must be > 0 lakhs.")
    if daily_km < 0:
        raise ValueError("Daily km must be >= 0.")

    budget_rs = float(budget_lakhs) * 100000.0
    fuel_pref_norm = normalize_fuel_type(fuel_pref)

    candidates = df.copy()

    # Hard filters (with graceful fallback)
    if fuel_pref_norm:
        filtered = candidates[candidates["Fuel_Type"] == fuel_pref_norm]
        if not filtered.empty:
            candidates = filtered

    if seats_pref is not None and "Seats" in candidates.columns:
        filtered = candidates[(candidates["Seats"].notna()) & (candidates["Seats"].between(seats_pref - 1, seats_pref + 1))]
        if not filtered.empty:
            candidates = filtered

    if want_isofix is True and "ISOFIX_flag" in candidates.columns:
        filtered = candidates[candidates["ISOFIX_flag"] == 1]
        if not filtered.empty:
            candidates = filtered

    # Prepare features for RF
    feat_cols = ["Price_Rs", "Fuel_Encoded", "Mileage", "Cost_per_km", "Seats", "ISOFIX_flag"]
    if "Fuel_Encoded" not in candidates.columns:
        # Ensure fuel encoding is present for candidates
        try:
            candidates["Fuel_Encoded"] = le_fuel.transform(candidates["Fuel_Type"].astype(str))
        except Exception:
            # If encoder misses classes, refit on union safely
            all_fuels = pd.Series(list(SUPPORTED_FUELS))
            le_fuel.fit(all_fuels)
            candidates["Fuel_Encoded"] = le_fuel.transform(candidates["Fuel_Type"].astype(str))

    X_cand = candidates[feat_cols].copy()
    X_cand = X_cand.fillna(X_cand.median(numeric_only=True))

    # Build synthetic user vector
    try:
        fuel_enc = le_fuel.transform([fuel_pref_norm])[0]
    except Exception:
        fuel_enc = int(np.round(candidates["Fuel_Encoded"].median()))

    user_row = {
        "Price_Rs": budget_rs,
        "Fuel_Encoded": fuel_enc,
        "Mileage": X_cand["Mileage"].median(),
        "Cost_per_km": X_cand["Cost_per_km"].median(),
        "Seats": float(seats_pref) if seats_pref is not None else X_cand["Seats"].median(),
        "ISOFIX_flag": 1 if want_isofix else 0
    }
    user_vec = np.array([user_row[c] for c in feat_cols]).reshape(1, -1)

    # Probabilities from RF for the synthetic user
    try:
        probs = rf.predict_proba(user_vec)[0]
        class_index = {c: i for i, c in enumerate(rf.classes_)}
        model_probs = candidates["Model"].astype(str).map(lambda m: probs[class_index[m]] if m in class_index else 1e-9).to_numpy()
    except (AttributeError, NotFittedError, KeyError, ValueError):
        # Fallback: uniform probabilities
        model_probs = np.ones(len(candidates), dtype=float)

    # Budget closeness score (closer price -> higher score)
    price_diff = np.abs(candidates["Price_Rs"].astype(float) - budget_rs)
    price_diff_max = max(price_diff.max(), 1.0)
    price_score = 1.0 - (price_diff / price_diff_max)

    # Efficiency score: lower cost_per_km is better
    cpk = candidates["Cost_per_km"].astype(float).replace([np.inf, -np.inf], np.nan)
    cpk_med = np.nanmedian(cpk) if np.isnan(cpk).any() else cpk.median()
    cpk = cpk.fillna(cpk_med)
    # Normalize inverse: small cpk -> high score
    cpk_norm = (cpk - cpk.min()) / (max(cpk.max() - cpk.min(), 1e-9))
    efficiency_score = 1.0 - cpk_norm

    # Combine scores (weights can be tuned)
    w_prob, w_price, w_eff = 0.6, 0.25, 0.15
    prob_norm = model_probs / (model_probs.sum() + 1e-12)
    price_norm = price_score / (price_score.sum() + 1e-12)
    eff_norm = efficiency_score / (efficiency_score.sum() + 1e-12)

    combined = w_prob * prob_norm + w_price * price_norm + w_eff * eff_norm
    candidates = candidates.assign(score=combined)

    # Daily running cost
    if fuel_pref_norm == "EV":
        # Use computed EV cost per km
        ev_cpk = candidates.apply(compute_ev_cost_per_km, axis=1)
        candidates["Daily_Running_Cost"] = (daily_km * ev_cpk).astype(float)
    else:
        unit_price = FUEL_PRICE_PER_UNIT.get(fuel_pref_norm, FUEL_PRICE_PER_UNIT["PETROL"])
        safe_mileage = candidates["Mileage"].astype(float).replace(0, np.nan).fillna(X_cand["Mileage"].median())
        candidates["Daily_Running_Cost"] = (daily_km / safe_mileage) * unit_price

    # Sort and select top_k
    top = candidates.sort_values("score", ascending=False).head(top_k)

    # Round for neatness
    for col in ["Price_Rs", "Mileage", "Cost_per_km", "Daily_Running_Cost", "score", "Electric_Range_km"]:
        if col in top.columns:
            top[col] = pd.to_numeric(top[col], errors="coerce").round(2)

    cols_out = [
        "Make", "Model", "Variant", "Fuel_Type", "Price_Rs", "Seats", "ISOFIX_flag",
        "Mileage", "Cost_per_km", "Electric_Range_km", "Daily_Running_Cost", "score"
    ]
    existing = [c for c in cols_out if c in top.columns]
    return top[existing]

# ---------------------------
# API-style Functions (for frontend use)
# ---------------------------

def get_models() -> dict:
    """
    Loads the frontend dataset and returns a dictionary mapping
    each 'Make' to a list of its unique 'Models'.
    
    Expected to be called after main() has run and created the CSV.
    """
    logging.info("API call: get_models()")
    try:
        df = pd.read_csv(FRONTEND_DATASET_PATH)
        # Get unique models for each make
        model_map = df.groupby("Make")["Model"].unique()
        # Convert numpy arrays to lists (which are JSON serializable)
        return {make: models.tolist() for make, models in model_map.items()}
    except FileNotFoundError:
        logging.error(f"Missing required file: {FRONTEND_DATASET_PATH}")
        return {}
    except Exception as e:
        logging.error(f"Error in get_models: {e}")
        return {}


def get_variants(make: str, model: str) -> list:
    """
    Loads the frontend dataset and returns a list of variants
    for a specific make and model.
    """
    logging.info(f"API call: get_variants(make={make}, model={model})")
    try:
        df = pd.read_csv(FRONTEND_DATASET_PATH)
        # Use .str.lower() for case-insensitive matching
        variants = df[
            (df["Make"].str.lower() == make.lower()) &
            (df["Model"].str.lower() == model.lower())
        ]["Variant"].unique()
        return variants.tolist()
    except FileNotFoundError:
        logging.error(f"Missing required file: {FRONTEND_DATASET_PATH}")
        return []
    except Exception as e:
        logging.error(f"Error in get_variants: {e}")
        return []


def estimate_expenses(make: str, model: str, variant: str, daily_km: float) -> Optional[dict]:
    """
    Estimates daily and annual costs for a specific car variant
    based on the pre-processed frontend dataset.
    """
    logging.info(f"API call: estimate_expenses(variant={variant}, daily_km={daily_km})")
    try:
        df = pd.read_csv(FRONTEND_DATASET_PATH)
        # Find the specific car row
        car_row = df[
            (df["Make"].str.lower() == make.lower()) &
            (df["Model"].str.lower() == model.lower()) &
            (df["Variant"].str.lower() == variant.lower())
        ]

        if car_row.empty:
            logging.warning(f"No car found for {make} {model} {variant}")
            return None

        car = car_row.iloc[0]

        # Get pre-computed costs from the dataset
        cost_per_km = car.get("Cost_per_km", np.nan)
        insurance_yr = car.get("Insurance_per_year", np.nan)
        maint_yr = car.get("Maintenance_per_year", np.nan)
        total_annual = car.get("Total_Annual_Cost", np.nan)

        if pd.isna(cost_per_km):
            logging.error(f"Cost_per_km is NaN for {make} {model} {variant}")
            return None

        # Calculate the dynamic cost based on user's daily_km
        daily_running_cost = cost_per_km * daily_km

        return {
            "make": car["Make"],
            "model": car["Model"],
            "variant": car["Variant"],
            "daily_km": daily_km,
            "cost_per_km": round(cost_per_km, 2),
            "daily_running_cost": round(daily_running_cost, 2),
            "insurance_per_year": round(insurance_yr, 2),
            "maintenance_per_year": round(maint_yr, 2),
            "total_annual_cost_fixed": round(total_annual, 2),
        }

    except FileNotFoundError:
        logging.error(f"Missing required file: {FRONTEND_DATASET_PATH}")
        return None
    except Exception as e:
        logging.error(f"Error in estimate_expenses: {e}")
        return None

def get_car_details(make: str, model: str, variant: str) -> Optional[dict]:
    """
    Retrieves all available details for a specific car variant
    from the pre-processed frontend dataset.
    """
    logging.info(f"API call: get_car_details(make={make}, model={model}, variant={variant})")
    try:
        df = pd.read_csv(FRONTEND_DATASET_PATH)
        
        # Find the specific car row using case-insensitive matching
        car_row = df[
            (df["Make"].str.lower() == make.lower()) &
            (df["Model"].str.lower() == model.lower()) &
            (df["Variant"].str.lower() == variant.lower())
        ]

        if car_row.empty:
            logging.warning(f"No car found for {make} {model} {variant}")
            return None

        # Get the first match (should be unique)
        car_details = car_row.iloc[0].to_dict()

        # Clean up for JSON (replace NaN with None)
        cleaned_details = {
            k: (None if pd.isna(v) else v) 
            for k, v in car_details.items()
        }

        return cleaned_details

    except FileNotFoundError:
        logging.error(f"Missing required file: {FRONTEND_DATASET_PATH}")
        return None
    except Exception as e:
        logging.error(f"Error in get_car_details: {e}")
        return None

def recommend_cars(
    budget_lakhs: float,
    fuel_pref: str,
    daily_km: float,
    seats_pref: Optional[int] = None,
    want_isofix: Optional[bool] = None,
    top_k: int = 5
) -> Optional[list]:
    """
    Public API function to get recommendations.
    Loads all required artifacts (model, encoders, full dataset)
    and returns a list of recommendation dictionaries.
    """
    logging.info(f"API call: recommend_cars(budget={budget_lakhs}L, fuel={fuel_pref})")
    try:
        # Load all required artifacts
        rf = joblib.load(MODEL_PATH)
        le_fuel = joblib.load(FUEL_ENCODER_PATH)
        # Use the FULL cleaned dataset, as recommend_top_k expects it
        df = pd.read_csv(CLEANED_DATASET_PATH) 
    except FileNotFoundError as e:
        logging.error(f"Missing required artifact: {e.filename}. Run main() to create artifacts.")
        return None
    except Exception as e:
        logging.error(f"Error loading artifacts: {e}")
        return None

    try:
        # Call the existing internal recommendation logic
        top_df = recommend_top_k(
            rf=rf,
            le_fuel=le_fuel,
            df=df,
            budget_lakhs=budget_lakhs,
            fuel_pref=fuel_pref,
            daily_km=daily_km,
            seats_pref=seats_pref,
            want_isofix=want_isofix,
            top_k=top_k
        )

        if top_df.empty:
            logging.info("No recommendations found matching criteria.")
            return []

        # Convert to API-friendly list of dicts
        # Replace NaN with None for valid JSON
        top_df = top_df.fillna(np.nan).replace([np.nan], [None])
        return top_df.to_dict('records')

    except Exception as e:
        logging.exception(f"Error during recommendation: {e}")
        return None


# ---------------------------
# Main runner
# ---------------------------
def main():
    logging.info("Starting backend processing: Load, Clean, Train, Save...")

    logging.info("Loading and cleaning dataset...")
    df = load_and_clean("cars_ds_final.csv", save_clean=True)
    if df.empty:
        logging.error("Stopping: Data loading/cleaning failed.")
        return

    logging.info("Applying KMeans clustering...")
    df_clustered, kmeans, scaler = apply_kmeans(df, n_clusters=3)

    logging.info("Training RandomForest (ISOFIX included)...")
    try:
        rf, le_fuel = train_random_forest(df_clustered, use_gridsearch=False)
    except ValueError as e:
        logging.error(f"Stopping: Model training failed. {e}")
        return

    # Save for frontend consumption
    frontend_cols = [
        "Make", "Model", "Variant", "Fuel_Type", "Price_Rs", "Mileage",
        "Cost_per_km", "Seats", "ISOFIX_flag", "Insurance_per_year",
        "Maintenance_per_year", "Total_Annual_Cost", "Electric_Range_km",
        "Battery_kWh"
    ]
    # Filter only for columns that actually exist in the final df
    existing_frontend_cols = [col for col in frontend_cols if col in df_clustered.columns]
    
    df_clustered[existing_frontend_cols].to_csv(FRONTEND_DATASET_PATH, index=False)
    logging.info(f"Saved frontend dataset to {FRONTEND_DATASET_PATH}")
    logging.info("Backend artifact creation complete.")
    
    # --- Example API function usage ---
    # This section now simulates a frontend calling your new functions
    logging.info("--- Testing API functions ---")

    # Example 1: Get all car models
    all_models = get_models()
    if all_models:
        logging.info(f"Loaded {len(all_models)} makes. (e.g., Maruti Suzuki models: {all_models.get('Maruti Suzuki', 'N/A')[:5]}...)")

    # Example 2: Get variants for a specific car
    variants = get_variants(make="Tata", model="Nexon")
    if variants:
        logging.info(f"Found variants for Tata Nexon: {variants}")

    # Example 3: Estimate costs for one of those variants
    expense_estimate = estimate_expenses(
        make="Tata", 
        model="Nexon", 
        variant=variants[0] if variants else "XZ+ (S)", # Use a known variant
        daily_km=70
    )
    if expense_estimate:
        print("\n--- Example Cost Estimation (Tata Nexon, 70km/day) ---")
        import json
        print(json.dumps(expense_estimate, indent=2))

    # Example 4: Get CNG recommendations
    print("\n--- Example Recommendation (CNG) ---")
    top5_cng = recommend_cars(
        budget_lakhs=6.0,
        fuel_pref="CNG",
        daily_km=30,
        seats_pref=5,
        want_isofix=True,
        top_k=5
    )
    if top5_cng:
        # Pretty print the first result
        print(json.dumps(top5_cng[0], indent=2))
    else:
        print("No CNG cars found.")

    # Example 5: Get EV recommendations
    print("\n--- Example Recommendation (EV) ---")
    top5_ev = recommend_cars(
        budget_lakhs=12.0,
        fuel_pref="EV",
        daily_km=30,
        seats_pref=5,
        want_isofix=True,
        top_k=5
    )
    if top5_ev:
        # Pretty print the first result
        print(json.dumps(top5_ev[0], indent=2))
    else:
        print("No EV cars found.")
# Example 3b: Get car details
    car_details = get_car_details(
        make="Tata",
        model="Nexon",
        variant=variants[0] if variants else "XZ+ (S)" # Use a known variant
    )
    if car_details:
        print(f"\n--- Example Get Details (Tata Nexon: {car_details['Variant']}) ---")
        # We already imported json
        print(json.dumps(car_details, indent=2))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        logging.exception(f"Fatal error in main: {e}")