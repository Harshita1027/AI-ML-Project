import subprocess
import time
import os  # <--- You need to import this module

# The file to check for
MODILE = "car_recommender_model.pkl"

print("--- 🚀 Launcher Started ---")

# Run backend.py
try:
    # 1. Check if the model file does NOT exist
    if not os.path.exists(MODILE):
        print(f"'{MODILE}' not found. Running backend.py to create it...")
        
        # Run the backend and wait for it to finish
        subprocess.run(["python", "backend.py"])
        
        print("Backend.py finished.")
    else:
        print(f"'{MODILE}' already exists. Skipping backend.")

except Exception as e:  # <--- Catches any error from the subprocess
    print(f"An error occurred while running backend.py: {e}")

# Optional: wait a moment before launching frontend
print("Waiting")
time.sleep(2)
# Run frontend.py
print("Launching frontend.py...")
try:
    subprocess.run(["python", "frontend.py"])
except Exception as e:
    print(f"An error occurred while running frontend.py: {e}")

print("--- Launcher Finished ---")